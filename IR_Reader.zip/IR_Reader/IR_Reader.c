/* serial_test.c

   Read/write data via serial I/O

   This program is distributed under the GPL, version 2
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <signal.h>
#include <ftdi.h>
#include <time.h>
#include <string.h>
#define PacketLength 134
struct ftdi_context *ftdi;
int IR_array_data[8][8];
unsigned char residue[1024] ;
static int exitRequested = 0;
static int frameNumber = 0;
static long int lastTime =0;
static int lastFrame = 0;
static int frameRate = 0;
/*
 * sigintHandler --
 *
 *    SIGINT handler, so we can gracefully exit when the user hits ctrl-C.
 */
static void sigintHandler(int signum)
{
	unsigned char buf2[1];
	buf2[0] = '~';
	int f = ftdi_write_data(ftdi, buf2, 1); // Asking PIC24F04KA200 microcontroller to stop sending data
	if( f < 0)
		printf("Error in writing data: ~ .\n");
    exitRequested = 1;
}
//prints system time 
long int print_time(){
    time_t     now;
    struct tm  ts;
    char       buf[80];
    // Get current time
    time(&now);
    // Format time, "ddd yyyy-mm-dd hh:mm:ss zzz"
    ts = *localtime(&now);
    strftime(buf, sizeof(buf), "%a %Y-%m-%d %H:%M:%S %Z", &ts);
    //printf("%ld,%s,%d\n", (long)now,buf,frameRate);
    if((long)now - lastTime >=1){
        frameRate = (frameNumber - lastFrame);
        lastFrame = frameNumber;
        lastTime = (long)now;
    }
    return (long)now;
    
}
//Extracts serial packets from raw data received from serial port
int find_packet_head(unsigned char *buf, int index, int len){
    //Each serail packet starts with ***
    int count = 0;
    int i=0;
    for(i=index; i< len; i++){
        if(buf[i]=='*'){
            count++;
            if(count ==3){
                return i -2;
            }
        }else{
            count = 0;
        }
    }
    return i;
}
//Copey source array to destinatino array starting from start_index for lenght of len
void array_copy(unsigned char* dest, unsigned char* source,int start_index, int len){
    
    for (int i=0;i<len;i++){
        dest[i] = source[start_index+i];
    }
}
//If there is not complete packet, buffer it at residue buffer 
void add_to_residue(unsigned char* buf, int index){
    int last_data_index =0;
    while(residue[last_data_index]!= 0){
        last_data_index++;
    }
    int i=0;
    while(i < index){
        residue[last_data_index+i] = buf[index];
        i++;
    }
}
//Prints content of serial packet received from FTDI module
void print_packet(unsigned char* buf,int index){
    frameNumber++;
    //printf("Frame %d\n",frameNumber);
    long int epoch= print_time();
    //printf("printing packet from index %d \n",index);
    //printf("%c%c%c\n", buf[index], buf[index +1], buf[ index +2]);     //First 3 characters [index: 0, 1, 2] are stars 
    
    int thermistor_data = ((int)buf[index + 4]<<8) | buf[index +3]; //Next 2 characters [index: 3, 4] are thermistor bytes

    //printf("Thermistor reading: %d\n", thermistor_data/16); //by looking at the datasheet, the LSB stands for 0.0625 degree C

    int k = index + 5; 
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            int high_byte = buf[k+1];
            unsigned char low_byte = buf[k];
            int temperature_reading = (high_byte << 8) | low_byte;
            IR_array_data[i][j] = temperature_reading;
            k+=2;
        }
    }   

    //What to do with the last 1 byte of buf? That is just a checksum.

    //Print the received data
    
    for(int i = 0; i < 8; i++){     
        printf("%ld %d %d ",epoch, frameNumber,thermistor_data/16);
        for(int j = 0; j < 8; j++)
                printf("%d ", IR_array_data[i][j]/4); //by looking at the datasheet, the LSB stands for .25 degree C.
           printf("\n");
    }
    fflush(stdout);
}
//interpret raw data
void interpret_data(unsigned char *buf, int len)
{
	int index = find_packet_head(buf,0,len);
    //printf("first index is %d \n",index);
	if(index != 0){
        add_to_residue(buf,index);
        //printf("printing from residue packet \n");
        print_packet(residue,0);
        memset(residue,0,sizeof residue);
    }else{
        if(residue[0] != 0){
           // printf("short packet !!!!!!!!!! \n");
            print_packet(residue,0);
            memset(residue,0,sizeof residue);
        }
    }
    while(index < len){
        if(len - index < 131 ){
            //printf("residue savend %d \n",len - index);
            array_copy(residue,buf,index ,len-index);
            return;
        }
        print_packet(buf,index);
        index+= PacketLength;
        index = find_packet_head(buf,index,len);
    }	
}

//added by hessam: print first n bytes of raw data
void print_raw_data(unsigned char * buf, int start,int end){
    for(int i =start ; i< end;i++){
        printf("%c ", buf[i]);
    }
    printf("\n");
}
int main(int argc, char **argv)
{
    unsigned char buf[1024];
    int f = 0, i;
    int vid = 0x403;
    int pid = 0x6015;
    int baudrate = 115200;
    int interface = INTERFACE_A; //INTERFACE_ANY;
    int retval = EXIT_FAILURE;
    // Init
    if ((ftdi = ftdi_new()) == 0)
    {
        fprintf(stderr, "ftdi_new failed\n");
        return EXIT_FAILURE;
    }

    fprintf(stderr,"Selecting interface.\n");
    // Select interface
    int debug_res = ftdi_set_interface(ftdi, interface);
       
    // Open device 
    f = ftdi_usb_open(ftdi, vid, pid);
    if (f < 0)
    {
        fprintf(stderr, "unable to open ftdi device: %d (%s)\n", f, ftdi_get_error_string(ftdi));
        exit(-1);
    }
    fprintf(stderr,"FTDI device is open now.\n");
	fprintf(stderr,"Setting up baudrate.\n");
    // Set baudrate
    f = ftdi_set_baudrate(ftdi, baudrate);
    if (f < 0)
    {
        fprintf(stderr, "unable to set baudrate: %d (%s)\n", f, ftdi_get_error_string(ftdi));
        exit(-1);
    }
	fprintf(stderr,"Baudrate (%d) set up done.\n",baudrate);
    
	fprintf(stderr,"Registering SIGINT handler.\n");
	
    signal(SIGINT, sigintHandler);
    printf("epoch frameN Ta 1 2 3 4 5 6 7 8 9\n");
    while (!exitRequested)
    {
    	unsigned char buf2[1];
    	buf2[0] = '*';
    	f = ftdi_write_data(ftdi, buf2, 1); //Ask PIC24F04KA200 microcontroller to start sending data
        memset(buf, 0, sizeof buf);
        usleep(1 * 10000);
        f = ftdi_read_data(ftdi, buf, sizeof(buf));
        if (f<0){
            fprintf(stderr, "Something is wrong. %d bytes read\n",f);
            usleep(1 * 1000000);
        }
        else if( f > 0)
        {
            fprintf(stderr, "read %d bytes\n", f);
            interpret_data(buf, f);
            fprintf(stdout, "\n");
            fflush(stderr);
            fflush(stdout);
        }
    }
    signal(SIGINT, SIG_DFL);
    retval =  EXIT_SUCCESS;
    ftdi_usb_close(ftdi);
    do_deinit:
    ftdi_free(ftdi);
    return retval;
}
