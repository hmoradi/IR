import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from scipy.ndimage.interpolation import map_coordinates
from sets import Set
import Queue
import operator
from collections import OrderedDict
from matplotlib.patches import Rectangle
import subprocess
from subprocess import Popen, PIPE

import time
import os
import signal
import io
from scipy import interpolate

class Region:
	def __init__(self,x,y,ri,rj,T,size):
		self.i = x
		self.j = y
		self.ri = ri
		self.rj = rj
		self.T = T
		self.size = size
		self.label = 0
		self.Heat = 0
		self.head_confidence = 0
		self.trunk_confidence = 0
		self.leg_confidence = 0
	def compare(self,otherRegion):
		if self.label - otherRegion.label == 0:
			return True
		return False
class Pixel:
	def __init__(self,i,j):
		self.i = i
		self.j = j

class Q_object:
	def __init__(self,frameN,Location,confidence):
		self.frameN = frameN
		self.Location = Location
		self.confidence = confidence

def read_from_csv(fileName):
	return pd.read_csv(fileName,delimiter=' ')

def calc_background(data,start,end,body_list):
	frames = np.empty([end-start+1,resolution,resolution])
	background = np.empty([resolution,resolution])
	index = 0
	
	for frameN in range (start, end):
		if frameN not in body_list:
			frameData = data[data['frameN']==frameN][['1','2','3','4','5','6','7','8']]
			if len(frameData.as_matrix()) >0:
				frames[index] = extend_resolution(frameData.as_matrix(),resolution)
				index +=1
	for i in range(0,resolution):
	 	for j in range(0,resolution):
	 		ewmas = pd.ewma(frames[:,i,j],span=60)
	 		background[i][j] = ewmas[len(ewmas)-1]
	return background


def mkdir_p(mypath):
    '''Creates a directory. equivalent to using mkdir -p on the command line'''

    from errno import EEXIST
    from os import makedirs,path

    try:
        makedirs(mypath)
    except OSError as exc: # Python >2.5
        if exc.errno == EEXIST and path.isdir(mypath):
            pass
        else: raise
def plot_frame(data , folder,filename):
	
	fig, ax = plt.subplots()
	heatmap = plt.imshow(data, cmap=plt.cm.coolwarm, interpolation='none')
	plt.colorbar()
	plt.savefig('./'+folder+'/'+str(filename)+'.png')
	plt.close()

def plot_frame_live(data , folder,filename , axx , figg):
	axx.clear()
	heatmap = axx.imshow(data, interpolation='none',vmin=0,vmax=15)
	#plt.title(str(folder)+str(filename))
	#plt.colorbar()
	figg.suptitle(str(folder)+str(filename))
	plt.draw()
	#plt.pause(0.1)

def plot_frame_range(start,end,folder,avg_window):
	avg_frame = define_empty_matrix(8,8)
	fig = plt.figure()
	ax = fig.add_subplot(111)
	plt.ion()
	plt.show()
	for frameN in range (start, end,avg_window):
		for i in range (0,avg_window):
			frameData = data[data['frameN']==frameN+i][['1','2','3','4','5','6','7','8']]
			avg_frame = np.add(avg_frame,frameData.as_matrix())
		#plot_frame(np.true_divide(avg_frame,avg_window),folder,str(frameN))

		plot_frame(extend_resolution(np.true_divide(avg_frame,avg_window),32),folder,str(frameN)+"extended",ax)
		avg_frame =[[0 for x in range(8)] for y in range(8)] 

def plot_frame_range_live(start,end,folder,avg_window):
	
	avg_frame = define_empty_matrix(8,8)
	fig = plt.figure()
	ax = fig.add_subplot(111)
	plt.ion()
	plt.show()
	for frameN in range (start, end,avg_window):
		for i in range (0,avg_window):
			frameData = data[data['frameN']==frameN+i][['1','2','3','4','5','6','7','8']]
			avg_frame = np.add(avg_frame,frameData.as_matrix())
		#plot_frame(np.true_divide(avg_frame,avg_window),folder,str(frameN))

		plot_frame_live(extend_resolution(np.true_divide(avg_frame,avg_window),32),folder,str(frameN)+"extended",ax)
		avg_frame =[[0 for x in range(8)] for y in range(8)] 

def plot_frame_marked(data,frameN,ax,confidence_info ,figg):
	ax.clear()

	pcm = ax.get_children()[2]
	heatmap = ax.imshow(data, cmap=plt.cm.coolwarm, interpolation='none')
	#plt.colorbar(heatmap)
	figg.suptitle(str(frameN)+" head -> Yellow ,trunk -> gray , leg -> grean")
	if confidence_info != None:
		headX , headY = confidence_info[1].j - confidence_info[1].rj ,confidence_info[1].i - confidence_info[1].ri
		trunkX , trunkY = confidence_info[2].j - confidence_info[2].rj ,confidence_info[2].i - confidence_info[2].ri
		legX , legY = confidence_info[3].j - confidence_info[3].rj ,confidence_info[3].i - confidence_info[3].ri
		currentAxis = plt.gca()
		currentAxis.add_patch(Rectangle((headX, headY), 2*confidence_info[1].rj, 2*confidence_info[1].ri,lw='2' ,edgecolor="yellow", fill=False))
		currentAxis.add_patch(Rectangle((trunkX, trunkY), 2*confidence_info[2].rj, 2*confidence_info[2].ri,lw='2', edgecolor="grey", fill=False))
		currentAxis.add_patch(Rectangle((legX, legY), 2*confidence_info[3].rj, 2*confidence_info[3].ri, lw='2',edgecolor="green", fill=False))
		print confidence_info[0],confidence_info[1].label,confidence_info[2].label,confidence_info[3].label
	
	plt.draw()
	plt.pause(0.01)

def extend_resolution(data,desired_size):
	#print "extending ",type(data)
	new_dims = []
	for original_length, new_length in zip((8,8), (desired_size,desired_size)):
		new_dims.append(np.linspace(0, original_length-1, new_length))
	coords = np.meshgrid(*new_dims, indexing='ij')
	extended = map_coordinates(data, coords)
	return extended

def define_empty_matrix(dim1,dim2):
	matrix = [[0 for x in range(dim1)] for y in range(dim2)] 
	return matrix

def add_neighbors(i,j,visited,labels,q):
	for k in [-1,0,1]:
		for l in [-1,0,1]:
			if i+k >= 0 and i+k < resolution and j+l >= 0 and j+l < resolution and labels[i+k][j+l] == 0 and visited[i+k][j+l] == 0:
				new_pixel = Pixel(i + k,j + l)
				q.put(new_pixel)
				visited[new_pixel.i][new_pixel.j] = 1
	return q

def label_frame_knn(data,q,Threshhold):
	
	labels = define_empty_matrix(resolution,resolution)
	
	current_label = 0
	label_size = {}
	for i in range(0,len(labels)):
		for j in range(0,len(labels)):
			visited = define_empty_matrix(resolution,resolution)
			if labels[i][j] == 0:
				current_pixel = Pixel(i,j)
				q.put(current_pixel)
				avg_T = data[i][j]
				component_size = 1
				current_label +=1
				labels[i][j] = current_label
				while q.empty() == False:
					pixel = q.get()
					if labels[pixel.i][pixel.j] == 0:
						pixel_T =  data[pixel.i][pixel.j]
						if abs( pixel_T - avg_T) < Threshhold and component_size < 0.15 *(resolution*resolution):
							avg_T = ((avg_T * component_size) + pixel_T) / (component_size + 1)
							component_size += 1
							labels[pixel.i][pixel.j] = current_label
							#print "labeling pixel",pixel.i,pixel.j," with lable",current_label
					add_neighbors(pixel.i,pixel.j,visited,labels,q)
				label_size[current_label] = component_size
				#print component_size
	return [labels,label_size]				

def region_marker(region_frame,labels,label,regionMark):
	for i in range (0,len(labels)):
		for j in range(0,len(labels[0])):
			if labels[i][j] == label:
				region_frame[i][j]= regionMark
	return region_frame
def shrink_regions(labels,regions):
	for label in regions.keys():
		flag = True
		shrink_width = True
		while flag:
			region = regions[label]
			start_i = max(region.i - region.ri,0)
			end_i = min(region.i + region.ri,resolution-1)
			start_j = max(region.j - region.rj,0)
			end_j = min(region.j + region.rj,resolution-1)
			area = (end_i -start_i)*(end_j-start_j)
			count = 0
			for i in range(start_i,end_i):
				for j in range(start_j,end_j):
					if (labels[i][j] != label):
						count += 1
			if float(count  - region.size) / float(region.size) > 0.2:
				#print "region shrinked !!!"
				if shrink_width == False:
					region.ri -= 1
					shrink_width = True
				else:
					region.rj -=1
					shrink_width = False
			else:
				flag = False
	return regions
def extract_regions(labels,data):
	regions = {}
	last_mapped_label = 1
	for i in range(0,len(labels)):
		for j in range(0,len(labels[0])):
			label = labels[i][j]
			if label not in regions.keys():
				regions[label] = Region(i,j,0,0,data[i][j],1)
				last_mapped_label = label
			region = regions[label]
			
			start_i = max(min(region.i - region.ri,i),0)
			end_i = min(max(region.i + region.ri,i),resolution-1)
			
			region.ri = (end_i - start_i )/2
			region.i = start_i + region.ri

			start_j  = max(min(region.j - region.rj,j),0)
			end_j = min(max(region.j + region.rj,j),resolution-1)
			
			region.rj = (end_j - start_j )/2
			region.j = start_j + region.rj
			
			region.T = (float(region.size * region.T) + float(data[i][j])) / float(region.size + 1)
			region.size +=1
			region.label = label
			region.Heat += float(data[i][j])
			regions[label] = region
			
	return regions


def sort_dict(data,feature):
	
	sorted_feature = sorted(data.values(),key=operator.attrgetter(feature),reverse=True)
	result = []
	i = 0
	for region in sorted_feature:
		result.append(region.label)
	return result

def print_list(regions,data):
	for region in data:
		print regions[region].T
def calc_head_confidence2(region,sorted_T,sorted_Heat,sorted_Height,sorted_size,regions):
	t_weight = 3
	heat_weight = 1
	size_weight  = 1
	height_weight = 1

	Tvalue = 1 - abs((region.T - regions[sorted_T[0]].T) / (regions[sorted_T[0]].T - regions[sorted_T[-1]].T))
	HeatValue = 1 - abs((region.Heat - regions[sorted_Heat[2]].Heat) / (regions[sorted_Heat[0]].Heat - regions[sorted_Heat[-1]].Heat))
	SizeValue = 1 -  abs( (region.size - (regions[sorted_size[2]]).size) / ((regions[sorted_size[0]]).size - (regions[sorted_size[-1]]).size))
	SizeValue = - abs(float(region.size - (0.05*resolution*resolution)) / float(0.1*resolution*resolution))
	#HeightValue = 1 -  abs( (region.i - (regions[sorted_Height[-1]]).i) / ((regions[sorted_Height[0]]).i - (regions[sorted_Height[-1]]).i))
	HeightValue = 1 - (float(region.i) / float(resolution))
	
	confidence = (t_weight*Tvalue + height_weight* HeightValue + size_weight* SizeValue +heat_weight* HeatValue) / (t_weight+height_weight+size_weight+height_weight+4.0)
	#if region.i > (.33)* resolution:
	#	confidence = 0
	return confidence

def calc_trunk_confidence2(region,sorted_T,sorted_Heat,sorted_Height,sorted_size,regions):
	t_weight = 3
	heat_weight = 1
	size_weight  = 1
	height_weight = 1
	Tvalue = 1 - abs((region.T - regions[sorted_T[0]].T) / (regions[sorted_T[0]].T - regions[sorted_T[-1]].T))
	HeatValue = 1 - abs((region.Heat - regions[sorted_Heat[0]].Heat) / (regions[sorted_Heat[0]].Heat - regions[sorted_Heat[-1]].Heat))
	SizeValue = 1 -  abs((region.size - (regions[sorted_size[0]]).size) / ((regions[sorted_size[0]]).size - (regions[sorted_size[-1]]).size))
	SizeValue = -abs(float(region.size - (0.05*resolution*resolution)) / float(0.1*resolution*resolution))
	#HeightValue = 1 -  abs((region.i - (regions[sorted_Height[-2]]).i) / ((regions[sorted_Height[0]]).i - (regions[sorted_Height[-1]]).i))
	HeightValue = 1 -  (float(abs(region.i - (resolution/2))) / float(resolution))
	
	confidence = (t_weight*Tvalue + height_weight* HeightValue + size_weight* SizeValue +heat_weight* HeatValue) / (t_weight+height_weight+size_weight+height_weight+4.0)
	#if region.i > (.66)* resolution or region.i < (0.33)*resolution:
	#	confidence = 0
	return confidence

def calc_leg_confidence2(region,sorted_T,sorted_Heat,sorted_Height,sorted_size,regions):
	t_weight = 3
	heat_weight = 1
	size_weight  = 1
	height_weight = 1
	Tvalue = 1 - abs((region.T - regions[sorted_T[0]].T) / (regions[sorted_T[0]].T - regions[sorted_T[-1]].T))
	HeatValue = 1 - abs((region.Heat - regions[sorted_Heat[1]].Heat) / (regions[sorted_Heat[0]].Heat - regions[sorted_Heat[-1]].Heat))
	SizeValue = 1 -  abs( (region.size - (regions[sorted_size[1]]).size) / ((regions[sorted_size[0]]).size - (regions[sorted_size[-1]]).size))
	SizeValue = -abs(float(region.size - (0.05*resolution*resolution)) / float(0.1*resolution*resolution))
	#HeightValue = 1 -  abs( (region.i - (regions[sorted_Height[-3]]).i) / ((regions[sorted_Height[0]]).i - (regions[sorted_Height[-1]]).i))
	HeightValue = ((float(region.i) / float(resolution)))
	
	confidence = (t_weight*Tvalue + height_weight* HeightValue + size_weight* SizeValue +heat_weight* HeatValue) / (t_weight+height_weight+size_weight+height_weight+4.0)
	#if region.i < (.66)* resolution:
	#	confidence = 0
	return confidence
def find_best_candidates(candidate_regions,sorted_head,sorted_trunk,sorted_leg,labels,fileName,frameN,data):
	for trunkLabel in sorted_trunk:
		trunk_region = candidate_regions[trunkLabel]
		if trunk_region is None:
			continue
		for headLabel in sorted_head:
			head_region = candidate_regions[headLabel]
			if head_region is None or head_region.compare(trunk_region):
				continue
			for legLabel in sorted_leg:
				leg_region = candidate_regions[legLabel]
				if leg_region is None or leg_region.compare(head_region) or leg_region.compare(trunk_region):
					continue
				isBody = check_body(head_region,trunk_region,leg_region)
				isBody2 = check_body2(head_region,trunk_region,leg_region,data)
				if(isBody == 0 and isBody2):
					confidence = (head_region.head_confidence + 2*trunk_region.trunk_confidence+leg_region.leg_confidence)/4.0
					region_frame = define_empty_matrix(resolution,resolution)
					region_frame = region_marker(region_frame,labels,head_region.label,head_region.label)
					region_frame = region_marker(region_frame,labels,trunk_region.label,trunk_region.label)
					region_frame = region_marker(region_frame,labels,leg_region.label,leg_region.label)
					return [confidence,head_region, trunk_region, leg_region]
	return None

def assign_confidence(regions,data,labels,frameN):
	
	sorted_T = sort_dict(regions,'T')
	print_list(regions,sorted_T)
	sorted_Heat = sort_dict(regions,'Heat')
	sorted_size = sort_dict(regions,'size')
	sorted_Height = sort_dict(regions,'i')
	
	candidate_regions = {}
	for region in regions.values():
		if (float(region.size) / float(resolution*resolution)) < 0.002 or (float(region.size) / float(resolution*resolution)) > 0.8:
			#print (float(region.size) / float(resolution*resolution))
			#print "skipping beacuse of size"
			continue
		if region.T  < 0.1 :
			#print "skipping beacuse of T"
			continue  
		
		region.head_confidence = calc_head_confidence2(region,sorted_T,sorted_Heat,sorted_Height,sorted_size,regions)
		region.trunk_confidence = calc_trunk_confidence2(region,sorted_T,sorted_Heat,sorted_Height,sorted_size,regions)
		region.leg_confidence = calc_leg_confidence2(region,sorted_T,sorted_Heat,sorted_Height,sorted_size,regions)
		candidate_regions[region.label] = region
		print region.label,region.i,region.j,region.T,region.size,region.head_confidence,region.trunk_confidence,region.leg_confidence

	if len(candidate_regions) < 3:
		print 'too few regions ',len(candidate_regions)
		return
	sorted_head = sort_dict(candidate_regions,'head_confidence')
	sorted_trunk = sort_dict(candidate_regions,'trunk_confidence')
	sorted_leg = sort_dict(candidate_regions,'leg_confidence')
	confidence_info = find_best_candidates(candidate_regions,sorted_head,sorted_trunk,sorted_leg,labels,fileName,frameN,data)
	return confidence_info

def is_aligned(region1, region2):
	if region1.i < region2.i:
		if region1.j > region2.j - region2.rj and region1.j < region2.j + region2.rj:
			return True
	return False
def is_overlab(region1,region2):
	start_j = max(region1.j - region1.rj,region2.j - region2.rj)
	end_j= min(region1.j + region1.rj,region2.j + region2.rj)
	overlap_j = max(end_j - start_j,0)
	#print "overlap j",overlap_j
	start_i = max(region1.i - region1.ri,region2.i - region2.ri)
	end_i= min(region1.i + region1.ri,region2.i + region2.ri)
	overlap_i = max(end_i - start_i,0)
	#print "overlap i ",overlap_i
	if float(overlap_j) / float((2*max(min(region1.rj,region2.rj),1))) > 0.7 and (float(overlap_i) / float((2*max(min(region1.ri,region2.ri),1)))) < 0.3 :
		return True
	return False

def check_body(head,trunk,leg):
	if is_aligned(head,trunk) and is_overlab(head,trunk):
		if is_aligned(trunk,leg) and is_overlab(trunk,leg):
			print "body 1"
			return 0
		else:
			if head.head_confidence + trunk.trunk_confidence > 0.35:
				print "body 2 head + trunk ", head.head_confidence+trunk.trunk_confidence
				return 0
			
			return 1
	else:
		if is_aligned(trunk,leg) and is_overlab(trunk,leg):
			if trunk.trunk_confidence + leg.leg_confidence > .35 :
				print "body 3 _ trunk + leg " ,trunk.trunk_confidence + leg.leg_confidence
				return 0
			
			return 2
		else:
			if trunk.trunk_confidence > 0.3:
				print "body 4 ",trunk.trunk_confidence
				return 0
			return 3

def count_greater_than_0(data):
	count = 0
	for i in range (0,len(data)):
		for j in range (0,len(data[0])):
			if data[i][j]> 0:
				count +=1
	return count

def check_body2(head,trunk,leg,data):
	min_i = int(min(head.i-head.ri,trunk.i - trunk.ri,leg.i - leg.ri))
	max_i = int(max(head.i+head.ri,trunk.i + trunk.ri,leg.i + leg.ri))

	min_j = int(min(head.j-head.rj,trunk.j - trunk.rj,leg.j - leg.rj))
	max_j = int(max(head.j+head.rj,trunk.j + trunk.rj,leg.j + leg.rj))
	print min_i,max_i
	data_array = np.array(data)
	#print data_array.shape()
	minT = min(data_array[np.ix_([1,3],[2,4])])
	# maxT = max(data[min_i,max_i][min_j,max_j])
	# data = np.as_matrix(data)
	# residue = data[min_i,max_i][min_j,max_j]
	# for t in range (minT,maxT):
	# 	residue = residue - t
	# 	non_zero = count_greater_than_0(residue)
	# 	if len(non_zero) / (max_i-min_i)*(max_j - min_j) > 0.8:
	# 		count += 1
	# 	if count >= 3:
	# 		return True
	return False
def calc_average(q,start,end):
	
	sum_ = 0
	count = 0
	index = 0
	for item in q.queue:
		if index >= start and index <= end:
			sum_ += float(item.Location)*item.confidence
			count += 1
		index +=1
	print "avg calc ",sum_,count
	return sum_ / max(count,1)

def extract_dir(q):
	sorted_q = sorted(q.queue, key=lambda x: x.Location)
	start = sorted_q[0]
	end = sorted_q[-1]
	log( "decide based on ")
	for item in q.queue:
		log(str(item.frameN)+' '+str(item.Location)+' '+str(item.confidence))

	if q.full() or (len(q.queue) > 1 and abs(start.Location - end.Location) > (1.0 * resolution) / 5.0):
		arr = np.array(q.queue)
		start_pos = calc_average(q,0,(len(q.queue)/2)-1)
		end_pos = calc_average(q,(len(q.queue)/2)+1,len(q.queue))
		print "direction based on ",start_pos,end_pos
		if end_pos > start_pos :
			print "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"
			print "left to right"
			print "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"
			log("Move from left to right"+str(start_pos)+" "+str(end_pos))
		else:
			print "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"
			print "right to left"
			print "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"
			log("Move from right to left"+str(start_pos)+" "+str(end_pos))
	q = Queue.Queue(5)
	return q

def update_state_3(frameN,confidence_info,Threshhold,q):
	if confidence_info != None and confidence_info[0] > Threshhold:
		location = (confidence_info[1].j + confidence_info[2].j + confidence_info[3].j)/3.0
		print len(q.queue)
		log("adding frame "+str(frameN)+" with confidence "+str(confidence_info[0])+"to the queue with len "+str(len(q.queue)))
		if q.full():
			temp = q.get()
			q_object = q.queue[0]
			if frameN - q_object.frameN > 15:
				log("extracting direction because no room for adding more frames")
				q = extract_dir(q) 
		q_object = Q_object(frameN,location,confidence_info[0])
		
		q.put(q_object)
	else:
		print "no body "
		if q.full() or (len(q.queue) > 0 and frameN - q.queue[0].frameN > 15) :
			log("extracting the direction at frame "+str(frameN))
			q = extract_dir(q)

	return q



def build_knn(data,start,end):
	Threshhold = 0.01	
	q_objects = Queue.Queue(5)
	fig = plt.figure(1)
	ax = fig.add_subplot(111)
	plt.ion()
	plt.show()
	#fig2 = plt.figure(2)
	#ax2 = fig2.add_subplot(111)
	#plt.ion()
	#plt.show()
	body_list = []
	for frameN in range (start, end):
		q = Queue.Queue(0)
		frameData = data[data['frameN']==frameN][['1','2','3','4','5','6','7','8']]
		extended_frame = extend_resolution(frameData.as_matrix(),resolution)
		maxDiff = np.max(extended_frame) - np.min(extended_frame)
		diff = np.percentile(extended_frame,90) - np.percentile(extended_frame,10)
		print "max diff is ",maxDiff," diff is ",diff
		if maxDiff > 4.0 and diff > 2:
			print "building the model for frame ",frameN
			labels = label_frame_knn(extended_frame,q,Threshhold)
			#plot_frame_live(labels[0],"test",str(frameN),ax2,fig2)
			print "number of labels ",len(labels[1].keys())
			regions = extract_regions(labels[0],extended_frame)
			regions = shrink_regions(labels[0],regions)
			
			confidence_info = assign_confidence(regions,extended_frame,labels[0],frameN)
			if confidence_info != None:
				log("calculated confidence for frame "+str(frameN)+ "is "+str(confidence_info[0])+ " at location "+str(confidence_info[1]))
			if confidence_info != None and confidence_info[0] > 0.40:
				body_list.append(frameN)

			q_objects = update_state_3(frameN,confidence_info,0.40,q_objects)
			plot_frame_marked(extended_frame,str(frameN),ax,confidence_info,fig)
		else:
			confidence_info = None
			q_objects = update_state_3(frameN,confidence_info,0.40,q_objects)
			plot_frame_marked(extended_frame,str(frameN),ax,confidence_info,fig)
		accept = raw_input('OK? ')
		if accept == 'n':
			return
def build_knn_live(data,frameN,ax):
	Threshhold = 0.5	
	last_body_index = 0
	q_objects = Queue.Queue(7)
	

	q = Queue.Queue(0)
	frameData = data[frameN]
	if frameN - background_window > 0:
		print "correct background"
		background = calc_background_live(data,frameN-background_window-last_body_index,frameN -1 - last_body_index)
	else:
		background = calc_background_live(data,0,frameN)
	extended_background = extend_resolution(background,resolution)
	extended_frame = extend_resolution(np.array(frameData),resolution)
	residue = np.absolute(np.subtract(extended_frame,extended_background))
	maxDiff = np.max(residue) - np.min(residue)
	if maxDiff > 4.0:
		print "building the model for frame ",frameN
		log("building the model for frame "+str(frameN))
		labels = label_frame_knn(residue,q,Threshhold)
		regions = extract_regions(labels[0],residue)
		regions = shrink_regions(labels[0],regions)
		confidence_info = assign_confidence(regions,residue,labels[0],frameN)
		if confidence_info != None:
			log("calculated confidence for frame "+str(frameN)+ "is "+str(confidence_info[0])+ " at location "+str(confidence_info[1]))
		if confidence_info != None and confidence_info[0] > 0.25:
			#confidence_list[frameN]= confidence_info
			last_body_index += 1
		else:
			last_body_index = 0
			#confidence_list = {}

		#q_objects = update_state_3(frameN,confidence_info,.25,q_objects)
		plot_frame_marked(residue,str(frameN),ax,confidence_info)
	else:
		confidence_info = None
		#q_objects = update_state_3(frameN,confidence_info,.25,q_objects)
		plot_frame_marked(residue,str(frameN),ax,confidence_info)

def build_knn_residue(data,start,end):
	Threshhold = 0.01	
	last_body_index = 0
	q_objects = Queue.Queue(5)
	fig = plt.figure(1)
	ax = fig.add_subplot(111)
	plt.ion()
	plt.show()
	#fig2 = plt.figure(2)
	#ax2 = fig2.add_subplot(111)
	#plt.ion()
	#plt.show()
	body_list = []
	for frameN in range (start, end):
		q = Queue.Queue(0)
		frameData = data[data['frameN']==frameN][['1','2','3','4','5','6','7','8']]
		background = calc_background(data,frameN-background_window,frameN - 1,body_list)
		extended_background = extend_resolution(background,resolution)
		extended_background = background
		extended_frame = extend_resolution(frameData.as_matrix(),resolution)
		residue = np.absolute(np.subtract(extended_frame,extended_background))
		maxDiff = np.max(residue) - np.min(residue)
		diff = np.percentile(residue,75) - np.percentile(residue,25)
		print "max diff is ",maxDiff," diff is ",diff
		if maxDiff > 4.0 and diff > 1.5:
			print "building the model for frame ",frameN
			log("building the model for frame "+str(frameN))
			#labels = label_frame_knn(residue,q,Threshhold)
			labels = label_frame_knn(extended_frame,q,Threshhold)
			#plot_frame_live(labels[0],"test",str(frameN),ax2,fig2)
			#print "number of labels ",len(labels[1].keys())
			regions = extract_regions(labels[0],extended_frame)
			regions = shrink_regions(labels[0],regions)
			
			confidence_info = assign_confidence(regions,extended_frame,labels[0],frameN)
			if confidence_info != None:
				log("calculated confidence for frame "+str(frameN)+ "is "+str(confidence_info[0])+ " at location "+str(confidence_info[1]))
			if confidence_info != None and confidence_info[0] > 0.40:
				last_body_index += 1
				body_list.append(frameN)
				#print "last body index is ",last_body_index
			else:
				last_body_index = 0

			q_objects = update_state_3(frameN,confidence_info,0.40,q_objects)
			plot_frame_marked(extended_frame,str(frameN),ax,confidence_info,fig)
		else:
			confidence_info = None
			q_objects = update_state_3(frameN,confidence_info,0.40,q_objects)
			plot_frame_marked(extended_frame,str(frameN),ax,confidence_info,fig)
		accept = raw_input('OK? ')
		if accept == 'n':
			return
def log(msg):
	f = open('log.txt','a')
	f.write(str(msg)+'\n')
	f.close()

def run_IR_Reader():
    print "run ir reader is called"
    cmd = ["../build/IR_Reader"]
    i = 0
    data = np.empty([8,8])
    data_history = {}
    fig = plt.figure()
    ax = fig.add_subplot(111)
    plt.ion()
    plt.show()
    frameN = 0
    result = subprocess.Popen(cmd ,stdout=subprocess.PIPE)
    if result != None:
    	i = 0
    	data = define_empty_matrix(8,8)
    	while True:
	    	line = result.stdout.readline()
	    	if line != '':
	    	#the real code does filtering here
	    		#print "test:", line.rstrip(),len(line.rstrip().split(' '))
	    		line_s = line.rstrip().split(' ')
	    		if len(line_s) == 11:
		    		for j in range(0,8):
		    			data[i][j] = int(line_s[j+3]) 
	    			i += 1
	    			if i >= 8:
	    				i = 0
	    				data_history[frameN] = data
	 
	    				build_knn_live(data_history,frameN,ax)
	    				frameN += 1
	    				data = np.empty([8,8])
		    				
	    	else:
	    		print "error "
	    		break
    else:
    	print 'result not openned'
    	time.sleep(5)
    	os.kill(result.pid, signal.SIGINT)

fileName = '9'
resolution = 32
background_window = 20

mkdir_p(fileName)

mkdir_p(fileName)
mkdir_p(fileName+'/'+fileName+"_knn")
mkdir_p(fileName+'/'+fileName+"_confidence")
data = read_from_csv('../build/data/'+fileName+'.txt')


build_knn(data,126,160)



#plot_frame_range_live(1,731,fileName,5)

#run_IR_Reader()


